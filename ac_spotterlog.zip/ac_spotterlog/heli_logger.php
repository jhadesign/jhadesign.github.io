<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	<title>heli spotlog</title>
	<!-- FAVICON -->
	<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22256%22 height=%22256%22 viewBox=%220 0 100 100%22><text x=%2250%%22 y=%2250%%22 dominant-baseline=%22central%22 text-anchor=%22middle%22 font-size=%2275%22>🚁</text></svg>" />
	<!--- CSS -->
	<link rel="stylesheet" type="text/css" href="bootstrap_v.5.0.1.min.css">
	<!-- FONT -->
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/88f3966c13.js" crossorigin="anonymous"></script>
	<!-- JS -->
	<script src="bootstrap_v.5.0.1.min.js"></script>
	<!--- Page CSS -->
	<style>
body {
	padding: 1em;
	font-family: 'Lato', sans-serif;
	font-size: 0.875em;
}

.table {
	margin-left: auto;
	margin-right: auto;
	white-space: nowrap;
	border-collapse: separate;
	border-spacing: 0;
	min-width: 350px;
	text-align: right;
}

.table-dark {
	--bs-table-bg: #767676;
	--bs-table-striped-bg: #7D7D7D;
	--bs-table-striped-color: #fff;
	--bs-table-active-bg: #fff;
	border-color: rgba(255, 255, 255, 0.1);
}

th {
	border-bottom: 0px;
	background-color: #666 !important;
}

.tablediv {
	width: 30%;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 5%;
}

@media only screen and (max-width: 600px) {
  body {
    padding: 0em;
    font-size: 0.55em;
  }
  .tablediv {
    margin-left: 0;
  }
}

tr:empty {
	display: none !important;
}
	/* top-left border-radius */
	
table tr:first-child th:first-child {
	border-top-left-radius: 6px;
}
	/* top-right border-radius */
	
table tr:first-child th:last-child {
	border-top-right-radius: 6px;
}
	/* bottom-left border-radius */
	
table tr:last-child td:first-child {
	border-bottom-left-radius: 6px;
}
	/* bottom-right border-radius */
	
table tr:last-child td:last-child {
	border-bottom-right-radius: 6px;
}

.emoji {
	font-size: 30px;
	vertical-align: middle;
	float: right;
	line-height: 2;
}

	</style>
	<script>
	function searchFlights() {
		var input, filter, table, tr, td, cell, i, j;
		input = document.getElementById("filterInput");
		filter = input.value.toUpperCase();
		table = document.getElementById("flightTable");
		tr = table.getElementsByTagName("tr");
		for(i = 1; i < tr.length; i++) {
			// Hide the row initially.
			tr[i].style.display = "none";
			td = tr[i].getElementsByTagName("td");
			for(var j = 0; j < td.length; j++) {
				cell = tr[i].getElementsByTagName("td")[j];
				if(cell) {
					if(cell.innerHTML.toUpperCase().indexOf(filter) > -1) {
						tr[i].style.display = "";
						break;
					}
				}
			}
		}
	}
	</script>
</head>

<body>
	<div class="tablediv">
		<div class="row">
			<h3 class="">FLIGHT LOG EKRH OG OMEGN</h3> </div>
		<div class="row">
			<div class="col-md-3">
				<div class="input-group">
					<input class="form-control border-end-0 border" type="search" value="search" id="filterInput" onkeyup="searchFlights()" onfocus="this.value=''"> <span class="input-group-append">
		                    <button class="btn btn-outline-secondary border-start-0 border ms-n5" type="button">
                	        	<i class="fa fa-search" font-size: 0.73em;"></i>
		                    </button>
                		</span> </div>
			</div>
			<div class="col-md-2">
				<div class="input-group">
					<select class="form-select" id="inputGroupSelect04" onchange="location = this.value;">
						<option selected value="">date</option>
						<?php
			                echo "<option value='" . basename($_SERVER['PHP_SELF']) . "'>" . "all dates" . "</option>";
			                for ($i = 0; $i <= 365; $i++)
			                {
			                $dato = strtoupper(date('dMy', mktime(0, 0, 0, date('m'), date('d')-$i, date('Y'))));
			                echo "<option value='" . basename($_SERVER['PHP_SELF']) . "?dato=$dato'>" . $dato . "</option>";
			                }
			        ?>
					</select>
				</div>
			</div>
		</div> <span class="emoji"><a style="text-decoration: none;" href="ac_logger.php">✈️</a></span> <span class="emoji"><a style="text-decoration: none;" href="heli_logger.php">🚁</a></span>
		<table id="flightTable" class="table table-striped table-dark table-hover text-right">
			<thead>
				<th>CALL SIGN</th>
				<th>ICAO HEX</th>
				<th>REG</th>
				<th>DATO</th>
				<th>TIDSPUNKT LOGGET (UTC)</th>
			</thead>
			<tbody>
<?php
if ($_GET)
{
    // set the date as set via the url
    $data = fopen("flights/" . htmlspecialchars($_GET['dato']) . ".csv", "r") or die("Unable to open file: " . htmlspecialchars($_GET['dato']) . ".csv");
    printFlights($data);
}

else
{
    for ($i = 0;$i <= 365;$i++)
    {
        $data = fopen("flights/" . strtoupper(date('dMy', mktime(0, 0, 0, date('m') , date('d') - $i, date('Y')))) . ".csv", "r") or die("Unable to open file: " . strtoupper(date('dMy', mktime(0, 0, 0, date('m') , date('d') - $i, date('Y')))) . ".csv");
        printFlights($data);
    }
}

function printFlights($data)
{

    $data_array = [];
    fgets($data); #skip first line
    # read lines in as arrays and push them to data array then pop out the last entry one by one
    while (($line = fgetcsv($data)) !== false) array_push($data_array, $line);
    while (($line = array_pop($data_array)) != 0)
    {

        // Cycle through the array
        $helicopter_callsigns = array(
            "RESCUE",
            "DOC",
            "MERLN",
            "RES"
        );

        foreach ($helicopter_callsigns as $helicopters)
        {
            if (strpos($line[0], $helicopters) === 0)
            {
                echo "<tr>";
                for ($j = 0;$icaohex[$j] != "";$j += 2)
                {
                    if ($icaohex[$j] == $line[1])
                    {
                        $line[2] = $icaohex[$j + 1];
                        break;
                    }
                }

                break;
            }
        }

        foreach ($line as $cell)
        {
            foreach ($helicopter_callsigns as $helicopters)
            {

                if (strpos($line[0], $helicopters) === 0)
                {
                    echo "<td>" . htmlspecialchars($cell) . "</td>";
                    break;
                }
            }
        }

        foreach ($helicopter_callsigns as $helicopters)
        {
            if (strpos($line[0], $helicopters) === 0)
            {
                echo "</tr>\n";
                break;
            }
        }

    }
    fclose($f);

}

?>

			</tbody>
		</table>
		<!-- CONTAINER DIV END -->
	</div>
	<div class="footer"> &nbsp; </div>

</html>
